"""A video player class."""

from .video_library import VideoLibrary
import random
playing_counter = 1

class VideoPlayer:
    """A class used to represent a Video Player."""

    def __init__(self):
        self._video_library = VideoLibrary()
        self.video_state = {}

    def number_of_videos(self):
        num_videos = len(self._video_library.get_all_videos())
        print(f"{num_videos} videos in the library")

    def show_all_videos(self):
        """Returns all videos."""
        videos = self._video_library.get_all_videos()
        sorted_videos = sorted(videos, key=lambda x: x.title)
        print("Here's a list of all available videos:")
        for index in range(len(sorted_videos)):
            if len(sorted_videos[index].tags) != 0:
                a = str(sorted_videos[index].tags)
                remove = ['(', ')', '\'', ',']
                for value in remove:
                    a = a.replace(value, '')
                print('\t' f"{sorted_videos[index].title}" ' ' f"({sorted_videos[index].video_id})" ' ' f"[{a}]")
            else:
                print('\t' f"{sorted_videos[index].title} ({sorted_videos[index].video_id}) []")

    def play_video(self, video_id):
        global playing_counter
        videos = self._video_library.get_all_videos()
        sorted_videos = sorted(videos, key=lambda x: x.title)

        play_array = ["amazing_cats_video_id", "another_cat_video_video_id", "funny_dogs_video_id",
                      "life_at_google_video_id", "video_about_nothing_video_id"]

        self.extra_items.get("current_video_id")


        new1 = 0
        while video_id != play_array[new1] and new1 <= 3:
            new1 += 1
        if video_id != play_array[new1]:
            print("Cannot play video: Video does not exist")
        elif playing_counter == 1:
            print("Playing video: " + sorted_videos[new1].title)
            old = new1
            playing_counter += 1
            return old
        else:
            new2 = new1
            print("Stopping video: " + sorted_videos[old].title)
            print("Playing video: " + sorted_videos[new2].title)
            old = new2
            return new2, old

    def stop_video(self, new2):
        """Stops the current video."""
        videos = self._video_library.get_all_videos()
        sorted_videos = sorted(videos, key=lambda x: x.title)
        if new2 != 0:
            print("Stopping video: " + sorted_videos[new2].title)
        else:
            print("Cannot stop video: No video is currently playing")

    def play_random_video(self):
        """Plays a random video from the video library."""
        videos = self._video_library.get_all_videos()
        sorted_videos = sorted(videos, key=lambda x: x.title)
        print("Playing video: " + sorted_videos[random.randint(0, 4)].title)

    def pause_video(self):
        """Pauses the current video."""

        print("pause_video needs implementation")

    def continue_video(self):
        """Resumes playing the current video."""

        print("continue_video needs implementation")

    def show_playing(self):
        """Displays video currently playing."""

        print("show_playing needs implementation")

    def create_playlist(self, playlist_name):
        """Creates a playlist with a given name.

        Args:
            playlist_name: The playlist name.
        """
        print("create_playlist needs implementation")

    def add_to_playlist(self, playlist_name, video_id):
        """Adds a video to a playlist with a given name.

        Args:
            playlist_name: The playlist name.
            video_id: The video_id to be added.
        """
        print("add_to_playlist needs implementation")

    def show_all_playlists(self):
        """Display all playlists."""

        print("show_all_playlists needs implementation")

    def show_playlist(self, playlist_name):
        """Display all videos in a playlist with a given name.

        Args:
            playlist_name: The playlist name.
        """
        print("show_playlist needs implementation")

    def remove_from_playlist(self, playlist_name, video_id):
        """Removes a video to a playlist with a given name.

        Args:
            playlist_name: The playlist name.
            video_id: The video_id to be removed.
        """
        print("remove_from_playlist needs implementation")

    def clear_playlist(self, playlist_name):
        """Removes all videos from a playlist with a given name.

        Args:
            playlist_name: The playlist name.
        """
        print("clears_playlist needs implementation")

    def delete_playlist(self, playlist_name):
        """Deletes a playlist with a given name.

        Args:
            playlist_name: The playlist name.
        """
        print("deletes_playlist needs implementation")

    def search_videos(self, search_term):
        """Display all the videos whose titles contain the search_term.

        Args:
            search_term: The query to be used in search.
        """
        print("search_videos needs implementation")

    def search_videos_tag(self, video_tag):
        """Display all videos whose tags contains the provided tag.

        Args:
            video_tag: The video tag to be used in search.
        """
        print("search_videos_tag needs implementation")

    def flag_video(self, video_id, flag_reason=""):
        """Mark a video as flagged.

        Args:
            video_id: The video_id to be flagged.
            flag_reason: Reason for flagging the video.
        """
        print("flag_video needs implementation")

    def allow_video(self, video_id):
        """Removes a flag from a video.

        Args:
            video_id: The video_id to be allowed again.
        """
        print("allow_video needs implementation")
